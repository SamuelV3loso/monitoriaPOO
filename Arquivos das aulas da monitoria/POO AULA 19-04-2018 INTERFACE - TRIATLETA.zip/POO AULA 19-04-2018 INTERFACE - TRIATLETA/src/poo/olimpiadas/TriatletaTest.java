package poo.olimpiadas;

public class TriatletaTest {
	public static void main(String[] args) {
		Triatleta shelton = new Triatleta("Shelton Silva", "534.567.178-63");
		
		shelton.treinar();
		shelton.competir();
		
		shelton.correr();
		shelton.nadar();
		shelton.pedalar();
		
		shelton.printDistanciaPercorrida();
		
	}
}
