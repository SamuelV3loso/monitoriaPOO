package poo.olimpiadas;


public interface Atleta {
	String UNIDADE_PADRAO = "km";
	
	void treinar();
	void competir();
}
