package poo.olimpiadas;

public interface Nadador extends Atleta {
	void nadar();
	void printDistanciaPercorrida();
}
