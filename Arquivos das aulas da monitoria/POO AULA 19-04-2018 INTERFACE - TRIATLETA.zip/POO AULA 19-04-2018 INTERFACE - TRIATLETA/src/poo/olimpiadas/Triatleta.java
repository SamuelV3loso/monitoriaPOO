package poo.olimpiadas;

public class Triatleta extends Pessoa implements Nadador, Ciclista, Corredor {
	private double distanciaPercorrida;
	
	public Triatleta(String nome, String cpf) {
		super(nome, cpf);
		distanciaPercorrida = 0;
	}

	@Override
	public void treinar() {
		System.out.println("O Triatleta " + getNome() + " está treinando...");
		
	}

	@Override
	public void competir() {
		System.out.println("O Triatleta " + getNome() + " está competindo...");
		
	}

	@Override
	public void correr() {
		System.out.println("O Triatleta " + getNome() + " está correndo...");
		distanciaPercorrida++;
		
	}

	@Override
	public void pedalar() {
		System.out.println("O Triatleta " + getNome() + " está pedalando...");
		distanciaPercorrida++;
		
	}

	@Override
	public void nadar() {
		System.out.println("O Triatleta " + getNome() + " está nadando...");
		distanciaPercorrida++;
		
	}
	
	@Override
	public void printDistanciaPercorrida() {
		System.out.println("O Triatleta " + getNome() 
		                   + " percorreu a distância de: " 
				           + distanciaPercorrida + Atleta.UNIDADE_PADRAO);
		
	}

	
	
	

}
