package poo.olimpiadas;


public interface Ciclista extends Atleta {
	void pedalar();
	void printDistanciaPercorrida();
}
