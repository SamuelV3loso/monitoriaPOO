package poo.olimpiadas;


public interface Corredor extends Atleta {
	void correr();
	void printDistanciaPercorrida();
}
