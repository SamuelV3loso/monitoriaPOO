package poo.sistemabancario;

public class ContaPoupanca extends Conta implements Investimento {

	private double taxa;

	public ContaPoupanca(int numero, Cliente titular) {
		super(numero, titular);
		taxa = 0.5;
	}
	
	public ContaPoupanca(int numero, Cliente titular, double taxa) {
		super(numero, titular);
		this.taxa = taxa;
	}
	
	//Sobreescrita de método
	public void aplicarRendimento() {
		double rendimento = getSaldo() * taxa;
		depositar(rendimento);
	}

	public double getTaxa() {
		return taxa;
	}

	@Override
	public void setTaxa(double taxa) {
		this.taxa = taxa;
		
	}

}
