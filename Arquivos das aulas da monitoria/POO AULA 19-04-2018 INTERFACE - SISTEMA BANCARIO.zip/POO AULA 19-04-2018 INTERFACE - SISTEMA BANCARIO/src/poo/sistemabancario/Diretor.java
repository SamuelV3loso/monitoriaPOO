package poo.sistemabancario;

public class Diretor extends Funcionario{

	public Diretor(String nome, String cpf, String departamento, double salario, String dataAdimissao) {
		super(nome, cpf, departamento, salario, dataAdimissao);
	}
	
	public double bonificar() {
		this.bonificacao += getSalario() * 0.05; 
		return this.bonificacao;
	}

}
