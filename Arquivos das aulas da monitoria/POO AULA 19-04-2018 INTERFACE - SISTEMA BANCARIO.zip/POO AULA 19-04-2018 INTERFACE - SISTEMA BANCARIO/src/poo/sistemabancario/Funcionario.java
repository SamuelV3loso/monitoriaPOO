package poo.sistemabancario;

public abstract class Funcionario extends Pessoa {
	private String departamento;
	private double salario;
	protected double bonificacao;
	private String dataAdimissao;

	public Funcionario(String nome, String cpf, String departamento, double salario, String dataAdimissao) {
		super(nome, cpf);
		this.departamento = departamento;
		this.salario = salario;
		this.dataAdimissao = dataAdimissao;
		this.bonificacao = 0;
	}

	public void imprimeDados() {
		System.out.println("\nNome: " + this.getNome());
		System.out.println("\nCPF: " + this.getCpf());
		System.out.println("Departamento: " + this.getDepartamento());
		System.out.println("Salário: " + this.getSalario());
		System.out.println("Data de Admissão: " + this.getDataAdimissao());
	}

	public void recebeAumento(double aumento) {
		salario += aumento;
	}

	public double getGanhoAnual() {
		return salario * 12;
	}

	public abstract double bonificar();

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public String getDataAdimissao() {

		return dataAdimissao;
	}

	public double getBonificacao() {
		return bonificacao;
	}
	
}
