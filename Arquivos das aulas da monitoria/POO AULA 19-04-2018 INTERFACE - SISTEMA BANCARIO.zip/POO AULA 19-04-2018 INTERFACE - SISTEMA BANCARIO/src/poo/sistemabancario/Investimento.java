package poo.sistemabancario;

public interface Investimento {
	double SELIC = 6.5;
	
	//Declaração do Método que rentabiliza o investimento
	void aplicarRendimento();
	
	double getTaxa();
	
	void setTaxa(double taxa);
}
