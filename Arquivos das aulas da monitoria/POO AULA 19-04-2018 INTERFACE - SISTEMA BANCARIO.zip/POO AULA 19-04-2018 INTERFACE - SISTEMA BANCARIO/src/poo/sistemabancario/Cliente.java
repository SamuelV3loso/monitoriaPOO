package poo.sistemabancario;

public class Cliente extends Pessoa {
	private String email;
	private String telefone;
	private String dataAbertura;
	private double renda;
	private static int qntCliente = 0;
	
	public Cliente(String nome, String cpf, String dataAbertura) {
		super(nome, cpf);
		this.dataAbertura = dataAbertura;
		this.email = "";
		this.telefone = "";
		this.renda = 0;
		qntCliente++;
	}
	
	public static int getQntCliente() {
		return qntCliente;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public double getRenda() {
		return renda;
	}

	public void setRenda(double renda) {
		this.renda = renda;
	}

	public String getDataAbertura() {
		return dataAbertura;
	}
	
}
