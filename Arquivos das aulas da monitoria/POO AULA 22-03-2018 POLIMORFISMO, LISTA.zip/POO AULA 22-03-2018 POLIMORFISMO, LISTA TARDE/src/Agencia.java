import java.util.ArrayList;
import java.util.List;

public class Agencia {
	private String nome;
	private int numero;
	private List<Conta> contas;

	public Agencia(String nome, int numero) {
		super();
		this.nome = nome;
		this.numero = numero;
		contas = new ArrayList<Conta>();
				
	}

	public void cadastrarConta(Conta conta) {
		this.contas.add(conta);
		int indice = contas.size() - 1;
		//Conta c = (Conta) contas.get(indice); //Convertendo de Object para Conta
		
		System.err.println("Conta do " + contas.get(indice).getTitular().getNome() + " cadastrada ");	
	}
	
	public void removerConta(Conta conta) {
		this.contas.remove(conta);
		
		System.err.println("Conta do removida ");	
	}
	
}
