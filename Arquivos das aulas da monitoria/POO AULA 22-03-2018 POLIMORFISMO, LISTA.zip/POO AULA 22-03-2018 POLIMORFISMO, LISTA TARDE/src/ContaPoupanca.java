
public class ContaPoupanca extends Conta {

	public ContaPoupanca(int numero, Cliente titular) {
		super(numero, titular);
	}
	
	//Sobreescrita de método
	public void aplicarRendimento() {
		double rendimento = getSaldo() * 0.005;
		depositar(rendimento);
	}
	
	//Sobrecarga de método
	public void aplicarRendimento(double taxa) {
		double rendimento = getSaldo() * (taxa/100);
		depositar(rendimento);
	}

}
