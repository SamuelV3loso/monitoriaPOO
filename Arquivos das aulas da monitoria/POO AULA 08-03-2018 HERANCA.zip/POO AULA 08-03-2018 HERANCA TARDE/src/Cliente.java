
public class Cliente {
	private String nome;
	private String cpf;
	private String endereco;
	private String email;
	private String telefone;
	private String dataAbertura;
	private double renda;
	private static int qntCliente = 0;
	
	public Cliente(String nome, String cpf, String dataAbertura) {
		super();
		this.nome = nome;
		this.cpf = cpf;
		this.dataAbertura = dataAbertura;
		this.endereco = "";
		this.email = "";
		this.telefone = "";
		this.renda = 0;
		qntCliente++;
	}
	
	public static int getQntCliente() {
		return qntCliente;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public double getRenda() {
		return renda;
	}

	public void setRenda(double renda) {
		this.renda = renda;
	}

	public String getNome() {
		return nome;
	}

	public String getCpf() {
		return cpf;
	}

	public String getDataAbertura() {
		return dataAbertura;
	}
	
}
