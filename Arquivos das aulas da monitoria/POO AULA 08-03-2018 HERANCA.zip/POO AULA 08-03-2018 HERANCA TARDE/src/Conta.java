public class Conta extends Object { //Abre chaves da classe Conta
	//Declaração dos Atributos (Características)
	private int numero;
	private Cliente titular; //Implementa uma relação 1 para 1
	//private Cliente[] correntistas; //implementa uma relação 1 para muitos
	private double saldo;
	private double limite;
	private static int qntConta = 0;
	
	//Declaração do Construtor da Classe caso a realação entre Conta e Cliente seja de agregação
	public Conta(int numero, Cliente titular) {
		this.numero = numero;
		this.titular = titular;
		this.saldo = 0;
		this.limite = 0;
		qntConta = qntConta + 1;
	}
	
	public static int getQntConta() {
		return qntConta;
	}
	
	//Declaração do Construtor da Classe caso a realação entre Conta e Cliente seja de composição
		/*public Conta(int numero, String titular, String cpf, String dataAbertura) {
			this.numero = numero;
			this.titular = new Cliente(titular, cpf, dataAbertura);
			this.saldo = 0;
			this.limite = 0;
		}*/
	
	//Declaração dos Métodos (Comportamentos ou Ações)
	//Declaração do Método que realiza o saque na conta
	public boolean sacar(double valor) {
		if(valor > 0 && valor <= this.saldo) {
			this.saldo = this.saldo - valor;
			return true;
		} else {
			return false;
		}
	}
	
	//Declaração do Método que realiza o deposito na conta
	public boolean depositar(double valor) {
		if(valor > 0) {
			this.saldo = this.saldo + valor;
			return true;
		}
		
		return false;
	}
	
	public boolean tranferirPara(Conta destinatario, double valor) {
		if(this.sacar(valor)) {
			destinatario.depositar(valor);
			return true;
		}
		
		return false;
	}
	//Método acessor (retorna o valor do atributo titular)
	public Cliente getTitular() {
		return titular;
	}

	//Método acessor (retorna o valor do atributo numero)
	public int getNumero() {
		return numero;
	}

	//Método acessor (retorna o valor do atributo saldo)
	public double getSaldo() {
		return saldo;
	}
	
	public double getLimite() {
		return limite;
	}
	
	public void setLimite(double limite) {
		this.limite = limite;
	}
	
}//Fecha chaves da classe Conta