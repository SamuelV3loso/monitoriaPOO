public class Banco {
	public static void main(String[] args) {
		// Construindo (Instânciando) objetos da classe Conta
		Cliente cliente1 = new Cliente("Roberto Carlos", "111.222.333-54", "01/03/2018");
		Cliente cliente2 = new Cliente("Edel Pontes", "222.333.444-65", "28/02/2018");
		Cliente cliente3 = new Cliente("Michel Jackson", "444.333.555-76", "28/02/2016");
		
		System.out.println("Número de clientes criados: " + Cliente.getQntCliente());
		
		System.out.println("Número de contas criadas: " + Conta.getQntConta());
		
		Conta conta1 = new Conta(1, cliente1);
		
		System.out.println("Número de contas criadas: " + conta1.getQntConta());
		
		ContaCorrente conta2 = new ContaCorrente(2, cliente2);
		ContaPoupanca conta3 = new ContaPoupanca(3, cliente3);
	
		conta1.depositar(100);
		conta2.depositar(100);
		conta3.depositar(100);
		
		conta1.sacar(25);
		conta2.sacar(50);
		conta3.sacar(75);
		
		System.out.println("Saldo da conta: R$ " + conta1.getSaldo());
		System.out.println("Saldo da conta corrente: R$ " + conta2.getSaldo());
		System.out.println("Saldo da conta poupança: R$ " + conta3.getSaldo());

		System.out.println("Número de contas criadas: " + conta1.getQntConta());
		
		/*
		//Composição
				//Conta conta1 = new Conta(1, new Cliente("Roberto Carlos", "111.222.333-54", "01/03/2018"));
				//Conta conta2 = new Conta(2, new Cliente("Edel Pontes", "222.333.444-65", "28/02/2018"));
		
		// Depositar na conta 1
		double valor = 400.00;
		
		if (conta1.depositar(valor)) {
			System.out.println("Foi depositado R$" + valor + "na conta do " + conta1.getTitular().getNome());
			System.out.println("Saldo atual da conta do(a) " + conta1.getTitular().getNome() + " : R$" + 
			                  conta1.getSaldo());
		} else {
			System.err.println("Erro no deposito, operação não realizada");
		}

		// Depositar na conta 2
		valor = 700.0;

		if (conta2.depositar(valor)) {
			System.out.println("Foi depositado R$" + valor + "na conta do " + 
		                       conta2.getTitular());
			System.out.println("Saldo atual da conta do(a) " + conta2.getTitular() + 
					          " : R$" + conta2.getSaldo());
		} else {
			System.err.println("Erro no deposito, operação não realizada");
		}

		// conta 1 realizou a trasferencia para a conta 2
		valor = 100.0;

		if (conta1.tranferirPara(conta2, valor)) {
			System.out.println("Foi tranferido R$" + valor + "da conta do " + 
					conta1.getTitular().getNome() + " apara a conta do "+ conta2.getTitular());
			System.out.println("Saldo atual da conta do(a) " + conta1.getTitular().getNome() + 
					          " : R$" + conta1.getSaldo());
			System.out.println("Saldo atual da conta do(a) " + conta2.getTitular() + 
					           " : R$" + conta2.getSaldo());
		} else {
			System.err.println("Erro na tranferência, operação não realizada");
		}
		*/
		
	}
}