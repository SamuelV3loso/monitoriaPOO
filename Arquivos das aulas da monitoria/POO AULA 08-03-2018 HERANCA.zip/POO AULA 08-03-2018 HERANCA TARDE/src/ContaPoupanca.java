
public class ContaPoupanca extends Conta {

	public ContaPoupanca(int numero, Cliente titular) {
		super(numero, titular);
	}

}
