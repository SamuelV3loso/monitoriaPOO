
public class ContaCorrente extends Conta {

	public ContaCorrente(int numero, Cliente titular) {
		super(numero, titular);
	}

}
