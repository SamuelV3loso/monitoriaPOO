
public class Presidente extends Funcionario{

	public Presidente(String nome, String cpf, String departamento, double salario, String dataAdimissao) {
		super(nome, cpf, departamento, salario, dataAdimissao);
	}
	
	public double bonificar() {
		this.bonificacao += getSalario() * 0.1; 
		return this.bonificacao;
	}

}
