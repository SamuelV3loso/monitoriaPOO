
public class Gerente extends Funcionario {

	public Gerente(String nome, String cpf, String departamento, double salario, String dataAdimissao) {
		super(nome, cpf, departamento, salario, dataAdimissao);
	}

	public double bonificar() {
		this.bonificacao += getSalario() * 0.01; 
		return this.bonificacao;
	}
	
}
