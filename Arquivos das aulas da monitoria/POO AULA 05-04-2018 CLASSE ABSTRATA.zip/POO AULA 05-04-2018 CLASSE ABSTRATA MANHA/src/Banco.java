public class Banco {
	public static void main(String[] args) {
		// Construindo (Instânciando) objetos da classe Conta
		Cliente cliente1 = new Cliente("Roberto Carlos", "111.222.333-54", "01/03/2018");
		Cliente cliente2 = new Cliente("Edel Pontes", "222.333.444-65", "28/02/2018");
		Cliente cliente3 = new Cliente("Michel Jackson", "444.333.555-76", "28/02/2016");
		
		System.out.println(true);
		System.out.println(10.1);	
		System.out.println(cliente1);
		System.out.println("Número de clientes criados: " + Cliente.getQntCliente());
		
		System.out.println("Número de contas criadas: " + Conta.getQntConta());
		
		Conta conta1 = new ContaPoupanca(1, cliente1);
		
		System.out.println("Número de contas criadas: " + conta1.getQntConta());
		
		Conta conta2 = new ContaCorrente(2, cliente2);
		ContaPoupanca conta3 = new ContaPoupanca(3, cliente3);
	
		Agencia agenciaIfal = new Agencia("Agência do IFAL", 167241);
		
		agenciaIfal.cadastrarConta(conta1);
		agenciaIfal.cadastrarConta(conta2);
		agenciaIfal.cadastrarConta(conta3);
		
		conta1.depositar(100);
		conta2.depositar(100);
		conta3.depositar(100);
		
		conta1.aplicarRendimento();
		conta2.aplicarRendimento();
		conta3.aplicarRendimento();
		conta3.aplicarRendimento(1.0);
		
		System.out.println("Saldo da conta: R$ " + conta1.getSaldo());
		System.out.println("Saldo da conta corrente: R$ " + conta2.getSaldo());
		System.out.println("Saldo da conta poupança: R$ " + conta3.getSaldo());

		System.out.println("Número de contas criadas: " + conta1.getQntConta());
		
	}
}