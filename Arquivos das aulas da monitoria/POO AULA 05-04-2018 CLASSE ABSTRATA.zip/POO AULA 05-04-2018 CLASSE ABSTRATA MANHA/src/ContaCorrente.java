
public class ContaCorrente extends Conta {

	public ContaCorrente(int numero, Cliente titular) {
		super(numero, titular);
	}

	public void aplicarRendimento() {
		double rendimento = getSaldo() * 0.001;
		depositar(rendimento);		
	}

}
